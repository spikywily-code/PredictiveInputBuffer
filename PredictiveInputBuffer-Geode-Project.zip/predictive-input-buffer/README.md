# Predictive Input Buffer v2.0.0

Windows Geode project for Geometry Dash 2.208, based on the supplied `main.cpp`.

## Build

This project requires the Geode SDK/CLI and a Windows-compatible C++ toolchain. From this folder, run:

```powershell
geode build
```

The resulting `inputbuffer.predictive.geode` package will be in the build output folder. Install it through Geode's in-game **Install from file** option or place it in the Geode mods folder.

## GitHub Actions alternative

Push this folder to a GitHub repository on the `main` branch, or run the workflow manually from **Actions → Build Geode mod**. Download the `PredictiveInputBuffer-geode` artifact from the completed workflow; it contains the compiled `.geode` file.

## Controls

- **F6**: cycle prediction stages (0.5f, 1f, 2f, 4f, 6f, 8f, custom, off)
- **K**: show/hide the live status panel

The original source includes `Windows.h` and Windows console APIs, so this project is configured for Windows only.
